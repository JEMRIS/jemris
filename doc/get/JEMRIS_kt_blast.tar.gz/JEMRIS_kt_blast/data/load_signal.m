function [M t]=load_signal(filename)
% load MR-signal form 'filename' (usually signals.h5)
% call[M t ]=load_signal(filename)

% in this example: only single channel data.
channel = 1;
A = (h5read ('signals.h5', sprintf('/signal/channels/%02i',channel-1)))';
t = h5read ('signals.h5', sprintf('/signal/times'));
[t,J]=sort(t);M=A(J,:);


