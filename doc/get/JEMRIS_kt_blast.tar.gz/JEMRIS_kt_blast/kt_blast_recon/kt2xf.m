%==========================================================================
% ESMRMB k-t methods tutorial
% 
% function to make kx-ky-r -> x-y-f
%
% Shaihan Malik 30-9-05. email: shaihan.malik@imperial.ac.uk
%==========================================================================


function result = kt2xf(kt)

result = ifft(kt,[],1);
result = ifft(result,[],2);
result = fft(result,[],3);

end