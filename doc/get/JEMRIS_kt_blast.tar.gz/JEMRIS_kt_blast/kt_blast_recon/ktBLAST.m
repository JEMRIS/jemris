%==========================================================================
% ESMRMB k-t methods tutorial
% 
% k-t BLAST reconstruction:
%   [recon,xf_filter] = ktBLAST(data,training_data,kt_grid,R,psi)
%
%   data = 3D undersampled data arranged as x-y-f
%   td   = 3D prior info (x-f domain), x-y-f
%   kt_grid = undersampling grid, kx-ky-t
%   R    = undersample factor
%   psi  = noise variance
%
% Shaihan Malik 20-6-08. email: shaihan.malik@imperial.ac.uk
%==========================================================================

function [recon,xf_filter] = ktBLAST(xf_data,training_data,kt_grid,R,psi)

[xs ys ts] = size(xf_data);

if exist('psi','var')~=1
    psi = 0.01;
end

PSF = kt2xf(kt_grid);
[xShift,yShift,fShift] = ind2sub(size(PSF),find(PSF>1e-5));
xShift = xShift-1;yShift=yShift-1;fShift=fShift-1;

%% calculate filter
% first get the denominator
filter_denom = zeros([xs ys ts]);
for i=1:R,
    filter_denom = filter_denom + circshift(abs(training_data).^2,...
                                        [xShift(i) yShift(i) fShift(i)]);
end
filter_denom = filter_denom + psi;

% now divide numerator
xf_filter = (abs(training_data).^2) ./ filter_denom;

%% multiply aliased data by filter
recon = xf_data .* xf_filter;

% rescale
recon = recon * R;

end