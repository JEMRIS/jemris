%==========================================================================
% ESMRMB k-t methods tutorial
% 
%  Simple undersampling routine for x-y-t data.  Will only undersample in
%  y, but allows changes to dkydt. Makes small-cell pattern
%
% Shaihan Malik 10-6-08. email: shaihan.malik@imperial.ac.uk
%==========================================================================

function kt_pat = kt_undersample_2d(R,dkydt)
 
if ~exist('dkydt','var')
    dkydt = 1;
end

% define basic sampling tile
kt_pat = zeros([R R]);

% set one ky sample to 1, all others 0
kt_pat(1,:)=1;

% shift this sample through time
for t=2:R,
    kt_pat(:,t)=circshift(kt_pat(:,1),[dkydt*(t-1) 0]);
end

end