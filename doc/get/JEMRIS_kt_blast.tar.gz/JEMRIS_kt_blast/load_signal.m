function [M t image F]=load_signal(filename)
% load MR-signal form 'filename' (usually signal01.bin)
% call[M t ]=load_signal(filename)


 t=[];M=[];I=[];
 
    f=fopen(sprintf(filename,i)); A=fread(f,Inf,'double','l');fclose(f);
   n=size(A,1)/4; A=reshape(A,4,n)';ti=A(:,1);[ti,J]=sort(ti);Mi(:,:,i)=A(J,2:4);
   d=diff(diff(ti));d(d<1e-5)=0;Ii=[0;find(d)+1;length(ti)];
   t=[t;ti];M=[M;Mi];I=[I;Ii];

